# hotel-mangement-system
this is hotel management system using PHP and MySQL Database 


## follow the guides

1. Download files into your server ( Local or Remote ) <br>
2. Import Database "hotel.SQL" <br>
3. Run the project <br>
4. Login and Use <br>
	
user name : - Admin <br>
password  : - 1234 <br>

ENJOY DDDD !
